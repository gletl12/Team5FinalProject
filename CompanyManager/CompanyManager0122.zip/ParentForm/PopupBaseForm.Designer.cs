﻿
namespace CompanyManager
{
    partial class PopupBaseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.popupTitleBar1 = new CompanyManager.PopupTitleBar();
            this.SuspendLayout();
            // 
            // popupTitleBar1
            // 
            this.popupTitleBar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(160)))), ((int)(((byte)(185)))));
            this.popupTitleBar1.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.popupTitleBar1.HeaderText = "HeaderText";
            this.popupTitleBar1.Location = new System.Drawing.Point(0, 1);
            this.popupTitleBar1.Name = "popupTitleBar1";
            this.popupTitleBar1.Size = new System.Drawing.Size(669, 33);
            this.popupTitleBar1.TabIndex = 0;
            // 
            // PopupBaseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(670, 564);
            this.Controls.Add(this.popupTitleBar1);
            this.Font = new System.Drawing.Font("나눔고딕", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PopupBaseForm";
            this.Text = "PopupBaseForm";
            this.Load += new System.EventHandler(this.PopupBaseForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        public PopupTitleBar popupTitleBar1;
    }
}