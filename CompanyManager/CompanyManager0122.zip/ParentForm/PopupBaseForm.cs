﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CompanyManager
{
    public partial class PopupBaseForm : Form
    {
      
        public PopupBaseForm()
        {
            InitializeComponent();
        }

        private void popupTitleBar1_Load(object sender, EventArgs e)
        {

        }

        private void titleBar1_Load(object sender, EventArgs e)
        {

        }

        private void PopupBaseForm_Load(object sender, EventArgs e)
        {

        }
    }
}
