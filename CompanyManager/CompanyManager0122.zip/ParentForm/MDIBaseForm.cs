﻿using Service;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using Util;

namespace CompanyManager
{
    public partial class MDIBaseForm : Form
    {
        public MDIBaseForm()
        {
            InitializeComponent();
        }

        private void MDIBaseForm_Load(object sender, EventArgs e)
        {
  
        }
    }
}
