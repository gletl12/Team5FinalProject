﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CompanyManager.Sample
{
    public partial class MDIListSample3 : CompanyManager.MDIBaseForm
    {
        public MDIListSample3()
        {
            InitializeComponent();
        }
    }
}
